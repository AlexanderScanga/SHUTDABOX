package alexander;



import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
/**
 * GuiDRIVER to show the application, with the tiles and values to play shut the box game
 * 
 * @author A. Scanga
 * @version 1.0
 */

public class GUIDriver2 extends Application {

    Die d1 = new Die(6);
    Die d2 = new Die(6);

    int currentPlayer = 1;
    boolean[] playerDone = new boolean[2];

    Tile[][] playerTiles = new Tile[2][9];
    Button[][] tileBtns = new Button[2][9];

    Label statusLabel = new Label("Player 1's turn");
    Label dieResult = new Label("");

    Button btnRoll = new Button("Roll Dice");
    Button lockIn = new Button("Lock IN");
    Button stopBtn = new Button("Stop");

    HBox btnRow = new HBox(10);

    @Override
    public void start(Stage stage) {
        VBox root = new VBox(10);
        root.setAlignment(Pos.CENTER);

        btnRow.setAlignment(Pos.CENTER);

        for (int i = 0; i < 9; i++) {
            
            for (int p = 0; p < 2; p++) {
                Tile tile = new Tile(i + 1);
                Button button = new Button(String.valueOf(i + 1));
                button.setStyle("-fx-background-color: #FFFFFF;");
                int player = p;

                button.setOnAction(e -> {
                    if (currentPlayer == player + 1) {
                        if (!tile.isDown()) {
                            if (!tile.isSelected()) {
                                tile.select();
                                button.setStyle("-fx-background-color: #DAF7A6;");
                            } else {
                                tile.deselect();
                                button.setStyle("-fx-background-color: #FFFFFF;");
                            }
                        }
                    }
                });

                playerTiles[p][i] = tile;
                tileBtns[p][i] = button;
            }
        }

        updateButtonRow();  // Set initial player's buttons

        btnRoll.setOnAction(e -> {
            int roll;
            if (onlyLowTilesLeft(playerTiles[currentPlayer - 1])) {
                roll = d1.roll();
                statusLabel.setText("Rolled 1 die");
            } else {
                roll = d1.roll() + d2.roll();
                statusLabel.setText("Rolled 2 dice");
            }
            dieResult.setText(String.valueOf(roll));
            btnRoll.setDisable(true);
        });

        lockIn.setOnAction(e -> {
            int sum = 0;
            Tile[] tiles = playerTiles[currentPlayer - 1];
            Button[] buttons = tileBtns[currentPlayer - 1];

            for (Tile t : tiles) {
                if (t.isSelected()) {
                    sum += t.getValue();
                }
            }

            if (dieResult.getText().isEmpty()) return;

            if (sum == Integer.parseInt(dieResult.getText())) {
                for (int i = 0; i < tiles.length; i++) {
                    if (tiles[i].isSelected()) {
                        tiles[i].deselect();
                        tiles[i].shut();
                        buttons[i].setDisable(true);
                        buttons[i].setStyle("-fx-background-color: #ff99ff;");
                    }
                }
                dieResult.setText("");
                btnRoll.setDisable(false);
                clearSelections(tiles, buttons);
            } else {
                statusLabel.setText("Sum doesn't match dice. Try again.");
                clearSelections(tiles, buttons);
            }
        });

        stopBtn.setOnAction(e -> {
            playerDone[currentPlayer - 1] = true;
            switchPlayerOrEnd();
        });

        root.getChildren().addAll(statusLabel, btnRow, btnRoll, dieResult, lockIn, stopBtn);
        Scene scene = new Scene(root, 600, 400);
        stage.setScene(scene);
        stage.show();
    }

    private void updateButtonRow() {
        btnRow.getChildren().clear();
        for (Button b : tileBtns[currentPlayer - 1]) {
            btnRow.getChildren().add(b);
        }
    }

    private void clearSelections(Tile[] tiles, Button[] buttons) {
        for (int i = 0; i < tiles.length; i++) {
            if (tiles[i].isSelected()) {
                tiles[i].deselect();
                buttons[i].setStyle("-fx-background-color: #FFFFFF;");
            }
        }
    }

    private boolean onlyLowTilesLeft(Tile[] tiles) {
        // Check if tiles 7, 8, 9 are all down
    	/**
    	 * Checks to see if you have tiles 7,8,9 down and if you do it takes the second die out of the equation 
    	 */
        return tiles[6].isDown() && tiles[7].isDown() && tiles[8].isDown();
    }

    private void switchPlayerOrEnd() {
    	/**
    	 * shows the winning player after both players are done their given turns
    	 */
        if (playerDone[0] && playerDone[1]) {
            int[] scores = new int[2];
            for (int p = 0; p < 2; p++) {
                for (Tile t : playerTiles[p]) {
                    if (!t.isDown()) scores[p] += t.getValue();
                }
            }
            String result;
            if (scores[0] < scores[1]) {
                result = "Player 1 wins! ";
            } else if (scores[0] > scores[1]) {
                result = "Player 2 wins! ";
            } else {
                result = "It's a tie!";
            }
            statusLabel.setText(result + " Final Scores — P1: " + scores[0] + ", P2: " + scores[1]);
            btnRoll.setDisable(true);
            lockIn.setDisable(true);
            stopBtn.setDisable(true);
        } else {
            currentPlayer = (currentPlayer == 1) ? 2 : 1;
            statusLabel.setText("Player " + currentPlayer + "'s turn");
            updateButtonRow();
            btnRoll.setDisable(false);
            dieResult.setText("");
        }
    }

    public static void main(String[] args) {
        launch();
    }
}
